
--// UI Script with Fixes and Enhancements //

-- Services
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local Stats = game:GetService("Stats")
local player = Players.LocalPlayer
local mouse = player:GetMouse()
local UIS = game:GetService("UserInputService")

-- Create UI elements (simplified for core example)
local ScreenGui = Instance.new("ScreenGui", player:WaitForChild("PlayerGui"))
ScreenGui.Name = "EnhancedUI"

-- Ping Display
local PingLabel = Instance.new("TextLabel")
PingLabel.Size = UDim2.new(0, 160, 0, 30)
PingLabel.Position = UDim2.new(0, 10, 0, 10)
PingLabel.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
PingLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
PingLabel.TextScaled = true
PingLabel.Text = "Ping: 0.00 ms"
PingLabel.Parent = ScreenGui

-- Ping Update
RunService.RenderStepped:Connect(function()
    local networkStats = Stats:FindFirstChild("PerformanceStats")
    if networkStats then
        local pingStat = networkStats:FindFirstChild("Ping")
        if pingStat then
            PingLabel.Text = string.format("Ping: %.2f ms", tonumber(pingStat.Value))
        end
    end
end)

-- Settings Menu
local SettingsFrame = Instance.new("Frame")
SettingsFrame.Size = UDim2.new(0, 220, 0, 300)
SettingsFrame.Position = UDim2.new(0, 180, 0, 10)
SettingsFrame.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
SettingsFrame.Visible = false
SettingsFrame.Draggable = true
SettingsFrame.Active = true
SettingsFrame.Parent = ScreenGui

local ToggleSettings = Instance.new("TextButton")
ToggleSettings.Size = UDim2.new(0, 120, 0, 40)
ToggleSettings.Position = UDim2.new(0, 10, 0, 50)
ToggleSettings.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
ToggleSettings.Text = "Settings"
ToggleSettings.TextColor3 = Color3.new(1,1,1)
ToggleSettings.Parent = ScreenGui

ToggleSettings.MouseButton1Click:Connect(function()
    SettingsFrame.Visible = not SettingsFrame.Visible
end)

-- Dash Extender (Moveable)
local DashExtender = Instance.new("Frame")
DashExtender.Size = UDim2.new(0, 140, 0, 50)
DashExtender.Position = UDim2.new(0, 10, 0, 100)
DashExtender.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
DashExtender.Active = true
DashExtender.Draggable = true
DashExtender.Parent = ScreenGui

-- Aimbot Sensitivity Slider (Draggable)
local SensitivityFrame = Instance.new("Frame")
SensitivityFrame.Size = UDim2.new(0, 200, 0, 50)
SensitivityFrame.Position = UDim2.new(0, 10, 0, 160)
SensitivityFrame.BackgroundColor3 = Color3.fromRGB(60, 60, 60)
SensitivityFrame.Parent = SettingsFrame

local SensitivityLine = Instance.new("Frame")
SensitivityLine.Size = UDim2.new(0, 180, 0, 6)
SensitivityLine.Position = UDim2.new(0, 10, 0.5, -3)
SensitivityLine.BackgroundColor3 = Color3.fromRGB(100, 100, 255)
SensitivityLine.BorderSizePixel = 0
SensitivityLine.Name = "Line"
SensitivityLine.Parent = SensitivityFrame

local Dot = Instance.new("Frame")
Dot.Size = UDim2.new(0, 10, 0, 10)
Dot.Position = UDim2.new(0, 90, 0.5, -5)
Dot.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Dot.Name = "Dot"
Dot.Parent = SensitivityLine

local dragging = false
Dot.InputBegan:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.Touch or input.UserInputType == Enum.UserInputType.MouseButton1 then
        dragging = true
    end
end)
Dot.InputEnded:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.Touch or input.UserInputType == Enum.UserInputType.MouseButton1 then
        dragging = false
    end
end)

UIS.InputChanged:Connect(function(input)
    if dragging and (input.UserInputType == Enum.UserInputType.Touch or input.UserInputType == Enum.UserInputType.MouseMovement) then
        local relX = input.Position.X - SensitivityLine.AbsolutePosition.X
        relX = math.clamp(relX, 0, SensitivityLine.AbsoluteSize.X)
        Dot.Position = UDim2.new(0, relX, 0.5, -5)
    end
end)
